library(testthat)
library(CircadianTools)

test_check("CircadianTools")
