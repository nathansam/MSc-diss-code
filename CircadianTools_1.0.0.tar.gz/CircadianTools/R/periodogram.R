periodogram <- function() {
    
    
}
